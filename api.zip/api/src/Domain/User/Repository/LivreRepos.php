<?php


namespace App\Domain\User\Repository;

use mysqli;
use PDO;

class LivreRepos
{
    private $connection;

    public function __construct(PDO $connection)
    {
        $this->connection = $connection;
    }

    public function listeLivres()
    {
        $result = "Results : ";
        $row = null;
        $sql = 'SELECT * FROM livres';
        @$mysqli = new mysqli("localhost", "root", "mysql", "libapi");
        $test = $mysqli->query($sql);
        if ($mysqli->affected_rows > 0) {
            while ($enreg = $test->fetch_row()) {
                $result = $result . $enreg[0] . ", Title : " . $enreg[2] . ", isbn: " . $enreg[3] . ' \\ ';
            }
            //$result = "Success";
        } else {
            $result = "No Results";
        }

        return $result;
    }
    public function livreRepos($_id){
        $result = "Results : ";
        $row = null;
        $sql = "SELECT * FROM livres WHERE id = $_id";
        @$mysqli = new mysqli("localhost", "root", "mysql", "libapi");
        $test = $mysqli->query($sql);
        if ($mysqli->affected_rows > 0) {
            while ($enreg = $test->fetch_row()) {
                $result = $result . $enreg[0] . ", Title : " . $enreg[2] . ", isbn: " . $enreg[3] . ' \\ ';
            }
            //$result = "Success";
        } else {
            $result = "No Results at :" . $_id;
        }

        return $result;
    }

    public function livreCreation($tab):string{
        $result = "Results : ";
        @$mysqli = new mysqli("localhost", "root", "mysql", "libapi");
        $sql = "INSERT INTO livres (genre_id,titre,isbn) VALUES ('$tab[0]','$tab[1]','$tab[2]')";
        $req = $this->connection->prepare($sql);
        if($req->execute() == true){
            $result = "Data Created! Titre du Livre : " . $tab[1];
        }else {
            $result = "0 Data Created! ". $tab[1];
        }
        return $result;
    }

    public function livreDelete($_id){
        $result = "Results : ";
        $sql = "DELETE FROM livres WHERE id = $_id";
        @$mysqli = new mysqli("localhost", "root", "mysql", "libapi");
        $req = $this->connection->prepare($sql);
        if($req->execute() == true){
            $result = "Data Removed! Livre : " . $_id;
        }else {
            $result = "0 Data Removed! ". $_id;
        }
        return $result;
    }

    public function livreUpdate($_id,$tab):string{
        $result = "Results : ";
        @$mysqli = new mysqli("localhost", "root", "mysql", "libapi");
        $sql = "UPDATE livres SET genre_id='$tab[0]',titre='$tab[1]',isbn='$tab[2]' WHERE id = '$_id'";
        $req = $this->connection->prepare($sql);
        if($req->execute() == true){
            $result = "Data Updated! <br> Livre : " . $_id;
        }else {
            $result = "0 Data Affected! <br> ". $tab[1];
        }
        return $result;
    }
}
?>
