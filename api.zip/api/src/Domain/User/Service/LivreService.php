<?php


namespace App\Domain\User\Service;


use App\Domain\User\Repository\LivreRepos;

class LivreService {

    private $repository;

    public function __construct(LivreRepos $repos)
    {
        $this->repository = $repos;
    }
    public function listelivres():string
    {
        if($this->repository->listeLivres()!=null){
            return strval($this->repository->listeLivres());
        }
        else{
            return "None";
        }
    }
    public function livreAt($_id):string{
        if($this->repository->livreRepos($_id)!=null){
            return strval($this->repository->livreRepos($_id));
        }
        else{
            return "None";
        }
    }
    public function livreCreate($tab):string{
            return strval($this->repository->livreCreation($tab));
    }
    public function DeleteLivreAt($_id):string{
        if($this->repository->livreDelete($_id)!=null){
            return strval($this->repository->livreDelete($_id));
        }
        else{
            return "None";
        }
    }
    public function UpdateLivre($_id,$modif){
        return strval($this->repository->livreUpdate($_id,$modif));
    }
}

?>
