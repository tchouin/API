<?php

namespace App\Action;

use App\Domain\User\Service\LivreService;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

class LivreListAction
{
    private $livreliste;

    public function __construct(LivreService $_livreListe)
    {
        $this->livreliste = $_livreListe;
    }

    public function __invoke(
        ServerRequestInterface $request,
        ResponseInterface $response
    ): ResponseInterface
    {
        //$data = (array)$request->getParsedBody();

        // Invoke the Domain with inputs and retain the result
        $data = $this->livreliste->listelivres();

        $result = json_encode([
            'code' => "Success",
            'Tab' => $data
        ]);

        $response->getBody()->write($result);

        return $response->withHeader('Content-Type', 'application/json');

    }
}

?>
