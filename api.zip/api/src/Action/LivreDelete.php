<?php

/**
 * Un fichier servant à :
 * @author Tomy Chouinard
 */

namespace App\Action;


use App\Domain\User\Service\LivreService;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

class LivreDelete {
    private $livreliste;

    public function __construct(LivreService $_livreListe)
    {
        $this->livreliste = $_livreListe;
    }

    public function __invoke(
        ServerRequestInterface $request,
        ResponseInterface $response
    ): ResponseInterface
    {
        $id = (array)$request->getQueryParams();

        // Invoke the Domain with inputs and retain the result
        $data = $this->livreliste->DeleteLivreAt($id["id"]);

        $result = json_encode([
            'Result' => $data
        ]);

        $response->getBody()->write($result);

        return $response->withHeader('Content-Type', 'application/json');

    }
}