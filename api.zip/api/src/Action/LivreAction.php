<?php


namespace App\Action;

use App\Domain\User\Service\LivreService;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

class LivreAction
{
    private $livreliste;

    public function __construct(LivreService $_livreListe)
    {
        $this->livreliste = $_livreListe;
    }

    public function __invoke(
        ServerRequestInterface $request,
        ResponseInterface $response
    ): ResponseInterface
    {
        $id = (array)$request->getQueryParams();

        // Invoke the Domain with inputs and retain the result
        $data = $this->livreliste->livreAt($id["id"]);

        $result = json_encode([
            'code' => "Success",
            'Tab' => $data
        ]);

        $response->getBody()->write((string)$result);

        return $response->withHeader('Content-Type', 'application/json');

    }
}

?>
