<?php

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Slim\App;

return function (App $app) {
    $app->get('/', \App\Action\HomeAction::class)->setName('home');

    $app->get('/livres',\App\Action\LivreListAction::class);

    $app->get('/livre',\App\Action\LivreAction::class);

    $app->post('/livre/create',\App\Action\LivreCreate::class);

    $app->post('/livre/delete',\App\Action\LivreDelete::class);

    $app->post('/livre/update',\App\Action\LivreUpdate::class);

    $app->post('/users', \App\Action\UserCreateAction::class);

};

