<?php


namespace App\Domain\Epreuve\Repository;


use PDO;

class resultRepos {
    private $connection;

    public function __construct(PDO $connection)
    {
        $this->connection = $connection;
    }
    public function resultAdd($tab):string{
        $result = "";
        $row = $tab;
        //@$mysqli = new mysqli("localhost", "root", "mysql", "libapi");
        $sql = "INSERT INTO resultat (id,athlete_id,epreuve_id,date_resultat,resultat_ms) VALUES ('$row[0]','$row[1]','$row[2]','$row[3]','$row[4]')";
        $req = $this->connection->prepare($sql);
        if($req->execute() == true){
            $result = $this->connection->lastInsertId();
        }else {
            $result = null;
        }
        return $result;
    }


}