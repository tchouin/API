<?php

namespace App\Domain\Epreuve\Repository;


use PDO;

class modifAthleteRepos {

    private $connection;

    public function __construct(PDO $connection)
    {
        $this->connection = $connection;
    }
    public function Update($_id,$tab):string{
        $result = "";
        //@$mysqli = new mysqli("localhost", "root", "mysql", "libapi");
        $sql = "UPDATE athletes SET adresse=:adresse,ville=:ville,courriel=:courriel WHERE id =:id";
        $req = $this->connection->prepare($sql);
        $req->execute(['adresse'=> $tab['adresse'],'ville'=> $tab['ville'],'courriel'=>$tab['courriel'],'id' => $_id['id']]);
        if($req){
            $result = "Les informations de l'athlète [". $_id['id'] ."] ont bien été modifiés";
        }
        else{
            $result = "l'id : ".$_id." est invalide!";
        }
        return $result;
    }
}