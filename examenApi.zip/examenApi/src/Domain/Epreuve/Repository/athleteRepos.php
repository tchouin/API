<?php

namespace App\Domain\Epreuve\Repository;
use PDO;

class athleteRepos {

    private $connection;

    public function __construct(PDO $connection)
    {
        $this->connection = $connection;
    }
    public function SearchAthlete($_id){
        $result = "";
        $row = null;
        $sql = "SELECT * FROM athletes WHERE id=:id";
        $exec = $this->connection->prepare($sql);
        $exec->execute(['id' => $_id['id']]);
        $tab = $exec->fetch();
        $result = implode('<br>',$tab);
        return $result;
    }
    public function ListAthlete($_ville){
        $result = "";
        $row = null;
        $sql = "SELECT * FROM athletes WHERE ville=:ville";
        $exec = $this->connection->prepare($sql);
        $exec->execute(['ville' => $_ville['ville']]);
        $tab = $exec->fetch();
        $result = implode('<br>',$tab);
        return $result;
    }
}