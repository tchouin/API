<?php


namespace App\Domain\Epreuve\Service;


use App\Domain\Epreuve\Repository\modifAthleteRepos;
use App\Factory\LoggerFactory;
use Slim\Middleware\ErrorMiddleware;

class modifService {
    private $repository;
    private $logger;
    public function __construct(modifAthleteRepos $repos,LoggerFactory $logger)
    {
        $this->repository = $repos;
        $this->logger = $logger
            ->addFileHandler('Updater.log')
            ->createLogger();
    }
    public function UpdateAthlete($_id,$modif){
        $res = strval($this->repository->Update($_id,$modif));
        if($res!=""){
            $this->logger->info('Code 201 %s');
            return $res;
        }
        else{
            $this->logger->info('Code 404 %s');
            return "";
        }
    }
}