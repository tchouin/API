<?php

namespace App\Domain\Epreuve\Service;


use App\Domain\Epreuve\Repository;
use App\Factory\LoggerFactory;

class athleteService {
    private $repository;
    private $logger;
    public function __construct(Repository\athleteRepos $repos,LoggerFactory $logger)
    {
        $this->repository = $repos;
        $this->logger = $logger
            ->addFileHandler('AthletesViewer.log')
            ->createLogger();
    }
    public function athleteAt($_id):string{
        if($this->repository->SearchAthlete($_id)!=null){
            return strval($this->repository->SearchAthlete($_id));
        }
        else{
            $this->logger->info('liste non détecté: %s');
            return "None";
        }
    }
    public function athleteBy($_ville):string{
        if($this->repository->ListAthlete($_ville)!=null){
            return strval($this->repository->ListAthlete($_ville));
        }
        else{
            $this->logger->info('la liste na rien fourni: %s');
            return "None";
        }
    }
}