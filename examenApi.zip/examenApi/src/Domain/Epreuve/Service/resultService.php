<?php


namespace App\Domain\Epreuve\Service;
use Monolog\Logger;
use App\Factory\LoggerFactory;
use App\Domain\Epreuve\Repository\resultRepos;


class resultService {

    private $repository;
    private $logger;
    public function __construct(resultRepos $repos,LoggerFactory $logger)
    {
        $this->repository = $repos;
        $this->logger = $logger
            ->addFileHandler('Transaction.log')
            ->createLogger();
    }
    public function resultAdd($tab):string{
        $res = strval($this->repository->resultAdd($tab));
        if($res == ""){
            $this->logger->info('ajout non réalisé: %s');
            return "None";
        }
        else{
            $this->logger->info('Le résultat a été inséré : '. $tab['id'] .' %s');
            return $res;
        }
    }
}