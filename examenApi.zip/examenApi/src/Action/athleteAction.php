<?php


namespace App\Action;


use App\Domain\Epreuve\Service;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

class athleteAction {

    private $athleteService;

    public function __construct(Service\athleteService $_athleteSearch)
    {
        $this->athleteService = $_athleteSearch;
    }

    public function __invoke(
        ServerRequestInterface $request,
        ResponseInterface $response
    ): ResponseInterface
    {
        $id = (array)$request->getQueryParams();

        // Invoke the Domain with inputs and retain the result
        $data = $this->athleteService->athleteAt($id["id"]);

        $result = json_encode([
            '' => $data
        ]);

        $response->getBody()->write((string)$result);

        return $response->withHeader('Content-Type', 'application/json');

    }
}