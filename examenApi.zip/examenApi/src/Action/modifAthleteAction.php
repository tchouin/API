<?php

namespace App\Action;


use App\Domain\Epreuve\Service\modifService;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

class modifAthleteAction {
    private $Services;
    public function __construct(modifService $service)
    {
        $this->Services = $service;
    }

    public function __invoke(
        ServerRequestInterface $request,
        ResponseInterface $response
    ): ResponseInterface {
        $id = (array)$request->getQueryParams();
        // Collect input from the HTTP request
        $data = (array)$request->getParsedBody();

        // Invoke the Domain with inputs and retain the result
        $mes = $this->Services->UpdateAthlete($id['id'],$data);

        // Transform the result into the JSON representation
        $result = [
            'message' => $mes
        ];
        if($mes != ""){
            $Code = 201;
        }else{
            $Code = 404;
        }

        // Build the HTTP response
        $response->getBody()->write((string)json_encode($result));

        return $response

            ->withHeader('Content-Type', 'application/json')
            ->withStatus($Code);
    }
}