<?php

namespace App\Action;

use App\Domain\Epreuve\Service\athleteService;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

class listeAthleteAction {
    private $athleteService;

    public function __construct(athleteService $_athleteSearch)
    {
        $this->athleteService = $_athleteSearch;
    }

    public function __invoke(
        ServerRequestInterface $request,
        ResponseInterface $response
    ): ResponseInterface
    {
        $ville = (array)$request->getQueryParams();

        // Invoke the Domain with inputs and retain the result
        $data = $this->athleteService->athleteBy($ville["ville"]);

        $result = json_encode([
            '' => $data
        ]);

        $response->getBody()->write((string)$result);

        return $response->withHeader('Content-Type', 'application/json');

    }
}