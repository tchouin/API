<?php

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Slim\App;

return function (App $app) {
    $app->get('/', \App\Action\HomeAction::class)->setName('home');

    // Documentation de l'api
    $app->get('/docs', \App\Action\Docs\SwaggerUiAction::class);

    // Sélection de toutes les épreuves
    $app->get('/epreuves', \App\Action\Epreuve\EpreuveViewAction::class);

    // Sélection d'un athlete'
    $app->get('/athlete', \App\Action\athleteAction::class);

    // Sélection d'un athlete'
    $app->post('/addResult', \App\Action\ajoutResult::class);

    // Sélection d'un athlete'
    $app->patch('/update', \App\Action\modifAthleteAction::class);

    // Sélection d'un athlete'
    $app->get('/listBy', \App\Action\listeAthleteAction::class);

};

